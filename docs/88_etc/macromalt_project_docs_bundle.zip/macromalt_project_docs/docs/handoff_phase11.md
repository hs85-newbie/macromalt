# Phase 11 Handoff

기준일: 2026-03-16  
상태: 설계 진행 기준 문서

## 목표
- theme / sub_axes / 종목군 수준의 반복 완화 규칙 추가
- 같은 테마가 강한 날에도 같은 질문 구조 반복을 줄인다
- 신규 데이터 소스 없이 최소 구현

## 설계 핵심
- `generator.py` 단독 수정
- theme fingerprint
- sub_axes fingerprint
- 종목군 fingerprint
- publish_history 확장
- 반복 감지 / 회전 지시 / 대체 종목군 지시
- 완전 차단 대신 감점/회전 우선

## 현재 보완 포인트
- `theme_fingerprint="기타"` 로그 남기기
- sub_axes 전체 fingerprint 로그 남기기
- stock bucket unmapped 경고 로그
- fallback 발동 여부 로그

## 다음 단계
- 최소 구현
- 정적 검증
- synthetic history 기반 감지 테스트
