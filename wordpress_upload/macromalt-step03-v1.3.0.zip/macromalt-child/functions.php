<?php
/**
 * Macromalt Child Theme functions and definitions
 * 
 * DESIGN TRACK: Step03 - Utility & Trust Surface Refinement
 * STRATEGY: GeneratePress Hooks Strategy (LOCKED)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * 1. Step02 - Global Shell & IA Refinement
 */

// 1.1 Homepage Editorial Masthead (Hero) Injection
add_action( 'generate_after_header', function() {
    if ( is_front_page() && ! is_paged() ) {
        ?>
        <div class="editorial-masthead">
            <div class="grid-container">
                <h1 class="masthead-title">MACROMALT</h1>
                <p class="masthead-tagline">INSTITUTIONAL RESEARCH FOR THE GLOBAL MACRO</p>
            </div>
        </div>
        <?php
    }
}, 15 );

// 1.2 Breadcrumb & Category Badge Injection
add_action( 'generate_before_content', function() {
    if ( is_front_page() || is_search() ) {
        return;
    }

    echo '<div class="editorial-shell-meta">';
    if ( is_category() ) {
        echo '<span class="shell-badge">CATEGORY:</span> ' . single_cat_title( '', false );
    } elseif ( is_single() ) {
        echo '<span class="shell-badge">INSIGHT:</span> ';
        the_category( ', ' );
    }
    echo '</div>';
}, 5 );

/**
 * 2. Step03 - Utility & Trust Surface Refinement
 */

// 2.1 Disclosure & Methodology Box (Single Posts Only)
add_action( 'generate_before_content', function() {
    if ( is_single() && ! is_page() ) {
        echo '<div class="editorial-disclosure-box">
                <span class="disclosure-heading">DISCLOSURE & METHODOLOGY</span>
                [CONCEPT PLACEHOLDER: 운영자가 정의한 투자 고찰 및 리서치 방법론 문구가 이곳에 위치합니다. 리서치 기관으로서의 신뢰 지표를 담은 2~3줄의 간결한 텍스트 작성을 권장합니다.]
              </div>';
    }
}, 10 );

// 2.2 Search Results Header
add_action( 'generate_before_main_content', function() {
    if ( is_search() ) {
        echo '<div class="search-results-label">SEARCHING THE MACROMALT ARCHIVE:</div>';
    }
}, 5 );

// 2.3 Footer Trust Micro-layer (Append)
add_action( 'generate_after_footer_content', function() {
    echo '<div class="footer-trust-layer">
            © 2026 MACROMALT. ALL RIGHTS RESERVED. INSTITUTIONAL RESEARCH FOR THE GLOBAL MACRO.
          </div>';
}, 20 );

// 2.4 Read More Text Refinement (Robust Filters)
add_filter( 'generate_excerpt_more', function( $more ) {
    return ' ...';
}, 20 );

add_filter( 'generate_content_more_link_output', 'macromalt_customize_read_more', 20 );
add_filter( 'generate_excerpt_more_output', 'macromalt_customize_read_more', 20 );
function macromalt_customize_read_more() {
    return sprintf(
        '<p class="read-more-container"><a title="%1$s" class="read-more" href="%2$s">%3$s</a></p>',
        the_title_attribute( 'echo=0' ),
        esc_url( get_permalink() ),
        __( 'FULL ANALYSIS →', 'generatepress' )
    );
}

/**
 * 3. Enqueue Parent Styles
 */
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_style( 'generatepress-style', get_template_directory_uri() . '/style.css' );
}, 1 );
?>
